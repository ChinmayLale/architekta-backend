import { Request, Response, NextFunction } from "express";
import { ApiError } from "../utils/apiError";
import { ApiResponse } from "../utils/apiResponse";
import { BlogsService } from "../services/Blogs.service";

const BlogsController = {
    
    async getAll(req: Request, res: Response, next: NextFunction) {
        try {
            const data = await BlogsService.getAll();
            return res.status(200).send(new ApiResponse(200, "Blogs fetched successfully", data));
        } catch (error) {
            console.error("❌ Error in getAll:", error);
            return next(new ApiError(500, "Failed to fetch Blogs"));
        }
    },
    

    

    
    async create(req: Request, res: Response, next: NextFunction) {
        try {
            const result = await BlogsService.create(req.body);
            return res.status(201).send(new ApiResponse(201, "Blogs created successfully", result));
        } catch (error) {
            console.error("❌ Error in create:", error);
            return next(new ApiError(500, "Failed to create Blogs"));
        }
    },
    

    

    
};

export default BlogsController;
