import { Request, Response, NextFunction } from "express";
import { ApiError } from "../utils/apiError";
import { ApiResponse } from "../utils/apiResponse";
import { UserService } from "../services/User.service";

const UserController = {
    
    async getAll(req: Request, res: Response, next: NextFunction) {
        try {
            const data = await UserService.getAll();
            return res.status(200).send(new ApiResponse(200, "User fetched successfully", data));
        } catch (error) {
            console.error("❌ Error in getAll:", error);
            return next(new ApiError(500, "Failed to fetch User"));
        }
    },
    

    

    
    async create(req: Request, res: Response, next: NextFunction) {
        try {
            const result = await UserService.create(req.body);
            return res.status(201).send(new ApiResponse(201, "User created successfully", result));
        } catch (error) {
            console.error("❌ Error in create:", error);
            return next(new ApiError(500, "Failed to create User"));
        }
    },
    

    

    
};

export default UserController;
