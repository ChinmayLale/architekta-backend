import { prisma } from "../config/db.config";
import { ApiError } from "../utils/apiError";


export const UserService = {
    async getAll() {
        try {
            return await prisma.user.findMany();
        } catch (error) {
            console.error("❌ Error in getAll:", error);
            throw new ApiError(500, "Failed to fetch User");
        }
    },

    async getById(id: string) {
        try {
            return await prisma.user.findUnique({
                where: { id },
            });
        } catch (error) {
            console.error("❌ Error in getById:", error);
            throw new ApiError(500, "Failed to fetch User");
        }
    },

    async create(data: any) {
        try {
            return await prisma.user.create({
                data,
            });
        } catch (error) {
            console.error("❌ Error in create:", error);
            throw new ApiError(500, "Failed to create User");
        }
    },

    async update(id: string, data: any) {
        try {
            return await prisma.user.update({
                where: { id },
                data,
            });
        } catch (error) {
            console.error("❌ Error in update:", error);
            throw new ApiError(500, "Failed to update User");
        }
    },

    async delete(id: string) {
        try {
            return await prisma.user.delete({
                where: { id },
            });
        } catch (error) {
            console.error("❌ Error in delete:", error);
            throw new ApiError(500, "Failed to delete User");
        }
    },
};
