import { prisma } from "../config/db.config";
import { ApiError } from "../utils/apiError";


export const BlogsService = {
    async getAll() {
        try {
            return await prisma.blogs.findMany();
        } catch (error) {
            console.error("❌ Error in getAll:", error);
            throw new ApiError(500, "Failed to fetch Blogs");
        }
    },

    async getById(id: string) {
        try {
            return await prisma.blogs.findUnique({
                where: { id },
            });
        } catch (error) {
            console.error("❌ Error in getById:", error);
            throw new ApiError(500, "Failed to fetch Blogs");
        }
    },

    async create(data: any) {
        try {
            return await prisma.blogs.create({
                data,
            });
        } catch (error) {
            console.error("❌ Error in create:", error);
            throw new ApiError(500, "Failed to create Blogs");
        }
    },

    async update(id: string, data: any) {
        try {
            return await prisma.blogs.update({
                where: { id },
                data,
            });
        } catch (error) {
            console.error("❌ Error in update:", error);
            throw new ApiError(500, "Failed to update Blogs");
        }
    },

    async delete(id: string) {
        try {
            return await prisma.blogs.delete({
                where: { id },
            });
        } catch (error) {
            console.error("❌ Error in delete:", error);
            throw new ApiError(500, "Failed to delete Blogs");
        }
    },
};
