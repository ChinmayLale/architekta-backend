import { Router } from "express";
import  UserController  from "../controllers/user.controller";
import { authenticate } from "../middleware/auth.middleware";

const router = Router();



router.post("/api/user", UserController.create);



export default router;
